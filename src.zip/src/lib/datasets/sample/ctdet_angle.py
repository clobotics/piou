from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch.utils.data as data
import numpy as np
import torch
import json
import cv2
import os
from utils.image import flip, color_aug
from utils.image import get_affine_transform, affine_transform
from utils.image import gaussian_radius, draw_umich_gaussian, draw_msra_gaussian
from utils.image import draw_dense_reg
import math


class CTDetAngleDataset(data.Dataset):
  def _coco_box_to_bbox(self, box):
    bbox = np.array([box[0], box[1], box[0] + box[2], box[1] + box[3]],
                    dtype=np.float32)
    return bbox

  # def _rotation_bbox_to_segmentation(self, bbox):
  #   """
  #   :param bbox: format [x_c, y_c, w, h, theta]
  #   :return: format [x1, y1, x2, y2, x3, y3, x4, y4]
  #   """
  #   box = cv2.boxPoints(((bbox[0], bbox[1]), (bbox[2], bbox[3]), bbox[4]))
  #   box = np.reshape(box, [-1, ])
  #   boxes = [box[0], box[1], box[2], box[3], box[4], box[5], box[6], box[7]]
  #   return np.array(boxes, dtype=np.float32)

  def _rotation_bbox_to_segmentation(self, bbox):
    """
    :param bbox: format [x_c, y_c, w, h, theta]
    :return: format [x1, y1, x2, y2, x3, y3, x4, y4]
    """
    cos_w = 0.5 * bbox[2] * math.cos(bbox[4])
    sin_w = 0.5 * bbox[2] * math.sin(bbox[4])
    cos_h = 0.5 * bbox[3] * math.cos(bbox[4])
    sin_h = 0.5 * bbox[3] * math.sin(bbox[4])
    x0 = bbox[0] + cos_w + sin_h
    y0 = bbox[1] - sin_w + cos_h
    x1 = bbox[0] - cos_w + sin_h
    y1 = bbox[1] + sin_w + cos_h
    x2 = bbox[0] - cos_w - sin_h
    y2 = bbox[1] + sin_w - cos_h
    x3 = bbox[0] + cos_w - sin_h
    y3 = bbox[1] - sin_w - cos_h
    corners = [x0, y0, x1, y1, x2, y2, x3, y3]
    return np.array(corners, dtype=np.float32)

  def _segmentation_to_rotation_bbox(self, rect):
    """
    :param rect: format [x1, y1, x2, y2, x3, y3, x4, y4]
    :param with_label: default True
    :return: format [x_c, y_c, w, h, theta]
    """
    box = np.int0(rect)
    box = box.reshape([-1, 2])
    rect = cv2.minAreaRect(box)
    rwidth, rheight = rect[1]
    rangle = rect[2]
    if rwidth > rheight:
      rangle = np.abs(rangle)
    else:
      temp = rwidth
      rwidth = rheight
      rheight = temp
      rangle = np.abs(rangle) + 90
    rbox = [rect[0][0], rect[0][1], rwidth, rheight, rangle / 180.0 * 3.141593]

    return np.array(rbox, dtype=np.float32)
  # def _segmentation_to_rotation_bbox(self, rect):
  #   """
  #   :param rect: format [x1, y1, x2, y2, x3, y3, x4, y4]
  #   :param with_label: default True
  #   :return: format [x_c, y_c, w, h, theta]
  #   """
  #   box = np.int0(rect)
  #   box = box.reshape([-1, 2])
  #   rect1 = cv2.minAreaRect(box)

  #   x, y, w, h, theta = rect1[0][0], rect1[0][1], rect1[1][0], rect1[1][1], rect1[2]
  #   boxes = [x, y, w, h, theta]
  #   return np.array(boxes, dtype=np.float32)

  def _get_border(self, border, size):
    i = 1
    while size - border // i <= border // i:
      i *= 2
    return border // i

  def __getitem__(self, index):
    img_id = self.images[index]
    file_name = self.coco.loadImgs(ids=[img_id])[0]['file_name']
    img_path = os.path.join(self.img_dir, file_name)
    ann_ids = self.coco.getAnnIds(imgIds=[img_id])
    anns = self.coco.loadAnns(ids=ann_ids)
    num_objs = min(len(anns), self.max_objs)
    img = cv2.imread(img_path)
    img = cv2.resize(img, (512, 512))
    self.split = 'train'
    height, width = img.shape[0], img.shape[1]
    c = np.array([img.shape[1] / 2., img.shape[0] / 2.], dtype=np.float32)
    if self.opt.keep_res:
      input_h = (height | self.opt.pad) + 1
      input_w = (width | self.opt.pad) + 1
      s = np.array([input_w, input_h], dtype=np.float32)
    else:
      s = max(img.shape[0], img.shape[1]) * 1.0
      input_h, input_w = self.opt.input_h, self.opt.input_w
    rot = 0
    flipped = False
    if self.split == 'train':
      if not self.opt.not_rand_crop and (1 == 0):
        s = s * np.random.choice(np.arange(0.6, 1.4, 0.1))
        w_border = self._get_border(128, img.shape[1])
        h_border = self._get_border(128, img.shape[0])
        c[0] = np.random.randint(low=w_border, high=img.shape[1] - w_border)
        c[1] = np.random.randint(low=h_border, high=img.shape[0] - h_border)
      else:
        sf = self.opt.scale
        cf = self.opt.shift
        c[0] += s * np.clip(np.random.randn()*cf, -2*cf, 2*cf)
        c[1] += s * np.clip(np.random.randn()*cf, -2*cf, 2*cf)
        s = s * np.clip(np.random.randn()*sf + 1, 1 - sf, 1 + sf)
      if np.random.random() < self.opt.aug_rot:
        rf = self.opt.rotate
        rot = np.clip(np.random.randn()*rf, -rf*2, rf*2)

      if np.random.random() < self.opt.flip:
        flipped = True
        img = img[:, ::-1, :]
        c[0] = width - c[0] - 1

    trans_input = get_affine_transform(
        c, s, rot, [self.opt.input_res, self.opt.input_res])
    inp = cv2.warpAffine(img, trans_input,
                         (self.opt.input_res, self.opt.input_res),
                         flags=cv2.INTER_LINEAR)
  # debug img
    # debug_img = inp.copy()

    inp = (inp.astype(np.float32) / 255.)
    if self.split == 'train' and not self.opt.no_color_aug:
      color_aug(self._data_rng, inp, self._eig_val, self._eig_vec)
    inp = (inp - self.mean) / self.std
    inp = inp.transpose(2, 0, 1)

    output_h = input_h // self.opt.down_ratio
    output_w = input_w // self.opt.down_ratio
    num_classes = self.num_classes
    trans_output_rot = get_affine_transform(c, s, rot, [output_w, output_h])
    # trans_output = get_affine_transform(c, s, 0, [output_w, output_h])

    hm = np.zeros((num_classes, output_h, output_w), dtype=np.float32)
    wh = np.zeros((self.max_objs, 2), dtype=np.float32)
    cxcy = np.zeros((self.max_objs, 2), dtype=np.float32)
    angle = np.zeros((self.max_objs, 1), dtype=np.float32)
    dense_wh = np.zeros((2, output_h, output_w), dtype=np.float32)
    reg = np.zeros((self.max_objs, 2), dtype=np.float32)
    ind = np.zeros((self.max_objs), dtype=np.int64)
    reg_mask = np.zeros((self.max_objs), dtype=np.uint8)
    cat_spec_wh = np.zeros((self.max_objs, num_classes * 2), dtype=np.float32)
    cat_spec_mask = np.zeros((self.max_objs, num_classes * 2), dtype=np.uint8)

    draw_gaussian = draw_msra_gaussian if self.opt.mse_loss else \
        draw_umich_gaussian
    gt_det_angle = []
    for k in range(num_objs):
      ann = anns[k]
      cls_id = int(self.cat_ids[ann['category_id']])
      segmentation = ann['segmentation'][0]
      segmentation = np.array(segmentation, dtype=np.float32)
      if flipped:
        segmentation[0::2] = width - segmentation[0::2] - 1
      segmentation[:2] = affine_transform(segmentation[:2], trans_output_rot)
      segmentation[2:4] = affine_transform(segmentation[2:4], trans_output_rot)
      segmentation[4:6] = affine_transform(segmentation[4:6], trans_output_rot)
      segmentation[6:8] = affine_transform(segmentation[6:8], trans_output_rot)
      
      if not self.opt.not_clip:
        cx = (segmentation[0] + segmentation[2] +
              segmentation[4] + segmentation[6]) / 4
        cy = (segmentation[1] + segmentation[3] +
              segmentation[5] + segmentation[7]) / 4
        if cx < 0 or cy < 0 or cx > output_w or cy > output_h:
          continue
        if np.abs(segmentation[2] - segmentation[0]) < 1e-4 or np.abs(segmentation[6] - segmentation[4]) < 1e-4:
          segmentation[0::2] = np.clip(segmentation[0::2], 0, output_w)
          segmentation[1::2] = np.clip(segmentation[1::2], 0, output_h)
        else:
          # line 0-1
          k_01 = (segmentation[3] - segmentation[1]) / \
              (segmentation[2] - segmentation[0])
          b_01 = segmentation[3] - k_01 * segmentation[2]
          # line 2-3
          k_23 = (segmentation[7] - segmentation[5]) / \
              (segmentation[6] - segmentation[4])
          b_23 = segmentation[7] - k_23 * segmentation[6]
          # 0
          if segmentation[0] < 0:
            segmentation[0] = 0
            segmentation[1] = b_01
          if segmentation[0] > output_w:
            segmentation[0] = output_w
            segmentation[1] = k_01 * output_w + b_01

          if segmentation[1] < 0:
            segmentation[1] = 0
            segmentation[0] = -b_01 / k_01
          if segmentation[1] > output_h:
            segmentation[1] = output_h
            segmentation[0] = (output_h-b_01) / k_01
          # 1
          if segmentation[2] < 0:
            segmentation[2] = 0
            segmentation[3] = b_01
          if segmentation[2] > output_w:
            segmentation[2] = output_w
            segmentation[3] = k_01 * output_w + b_01

          if segmentation[3] < 0:
            segmentation[3] = 0
            segmentation[2] = -b_01 / k_01
          if segmentation[3] > output_h:
            segmentation[3] = output_h
            segmentation[2] = (output_h-b_01) / k_01
          # 2
          if segmentation[4] < 0:
            segmentation[4] = 0
            segmentation[5] = b_23
          if segmentation[4] > output_w:
            segmentation[4] = output_w
            segmentation[5] = k_23 * output_w + b_23
          if segmentation[5] < 0:
            segmentation[5] = 0
            segmentation[4] = -b_23 / k_23
          if segmentation[5] > output_h:
            segmentation[5] = output_h
            segmentation[4] = (output_h-b_23) / k_23
          # 3
          if segmentation[6] < 0:
            segmentation[6] = 0
            segmentation[7] = b_23
          if segmentation[6] > output_w:
            segmentation[6] = output_w
            segmentation[7] = k_23 * output_w + b_23

          if segmentation[7] < 0:
            segmentation[7] = 0
            segmentation[6] = -b_23 / k_23
          if segmentation[7] > output_h:
            segmentation[7] = output_h
            segmentation[6] = (output_h-b_23) / k_23

      # debug corners
      # corners = segmentation.copy().reshape(-1, 1, 2) * self.opt.down_ratio
      # corners = corners.astype(int)
      # cv2.polylines(debug_img, [corners], True, (0, 255, 255), 2)

      bbox = self._segmentation_to_rotation_bbox(segmentation)
      ct_x, ct_y, w, h, theta = bbox
      if h == 0:
        h += 1
      if h > 0 and w > 0 and ct_x > 0 and ct_y > 0 and ct_x < output_w and ct_y < output_h:
        radius = gaussian_radius((math.ceil(h), math.ceil(w)))
        radius = max(0, int(radius))
        radius = self.opt.hm_gauss if self.opt.mse_loss else radius
        ct = np.array([ct_x, ct_y], dtype=np.float32)
        ct_int = ct.astype(np.int32)
        draw_gaussian(hm[cls_id], ct_int, radius)
        wh[k] = 1. * w, 1. * h
        ind[k] = ct_int[1] * output_w + ct_int[0]
        reg[k] = ct - ct_int
        angle[k] = theta
        cxcy[k] = 1. * ct_x, 1. * ct_y
        reg_mask[k] = 1
        cat_spec_wh[k, cls_id * 2: cls_id * 2 + 2] = wh[k]
        cat_spec_mask[k, cls_id * 2: cls_id * 2 + 2] = 1
        if self.opt.dense_wh:
          draw_dense_reg(dense_wh, hm.max(axis=0), ct_int, wh[k], radius)
        gt_det_angle.append([ct_x, ct_y, w, h, theta, 1, cls_id])

# save_debug_img
    # debug_path = "/home/czm/centernet-pytorch-1.1/debug/{}".format(file_name)
    # cv2.imwrite(debug_path, debug_img)

    ret = {'input': inp, 'hm': hm, 'reg_mask': reg_mask,
           'ind': ind, 'wh': wh, 'angle': angle, 'cxcy': cxcy}
    if self.opt.dense_wh:
      hm_a = hm.max(axis=0, keepdims=True)
      dense_wh_mask = np.concatenate([hm_a, hm_a], axis=0)
      ret.update({'dense_wh': dense_wh, 'dense_wh_mask': dense_wh_mask})
      del ret['wh']
    elif self.opt.cat_spec_wh:
      ret.update({'cat_spec_wh': cat_spec_wh, 'cat_spec_mask': cat_spec_mask})
      del ret['wh']
    if self.opt.reg_offset:
      ret.update({'reg': reg})
    if self.opt.debug > 0 or not self.split == 'train':
      gt_det_angle = np.array(gt_det_angle, dtype=np.float32) if len(gt_det_angle) > 0 else \
          np.zeros((1, 7), dtype=np.float32)
      meta = {'c': c, 's': s, 'gt_det_angle': gt_det_angle, 'img_id': img_id}
      ret['meta'] = meta
    # debug

    return ret
